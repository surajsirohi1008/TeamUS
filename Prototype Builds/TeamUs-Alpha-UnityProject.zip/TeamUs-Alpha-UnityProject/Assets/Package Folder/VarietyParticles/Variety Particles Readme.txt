------------------------
Variety Particles v1.5

by Kenneth Foldal Moe
------------------------

Hello, and thank you for purchasing Variety Particles!

To add a particle effect to your scene, simply drag one of the Particle Systems to your scene and start your scene to preview it.
At default, the particles are all looping for demonstrative purposes for the demo.

Remember to turn off Loop for when instantiating explosions and similar "one-shot" particle effects!
Most of the particles in this pack are very easy to recolor, so you can easily customize them to fit into your environment.

------------------------

If you have an issue, idea, or suggestion regarding the particles, feel free to shoot me an e-mail at archanor.work@gmail.com

Do you like the particle pack? Please rate and review it in the Unity Asset Store, this means a lot to me!