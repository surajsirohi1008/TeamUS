﻿using UnityEngine;

public class Projectile:MonoBehaviour
{
    [HideInInspector]
    public float damage, speed, size;
}
